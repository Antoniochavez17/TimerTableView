//
//  ViewController.swift
//  TimerTableView
//
//  Created by Antonio Adrian Chavez on 6/21/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TimeTableView: UITableView!
    
    var typeevent = ["part 1", "Part 2"]
    var timedate = ["3/14/2020 12:00:00 p", "4/16/2020 12:00:00 p"]
    // MARK: Calendar
    let formatter = DateFormatter()
    let userCleander = Calendar.current;
    let requestedComponent : Set<Calendar.Component> = [
        
        Calendar.Component.month,
        Calendar.Component.day,
        Calendar.Component.hour,
        Calendar.Component.minute,
        Calendar.Component.second
        
    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Countdown"
        
        // MARK:  this is face the error because there is no exist for timePrinter in which I put the timePrinter inside of the cells that out of the ViewController's statements.
         let timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timePrinter), userInfo: nil, repeats: true)
         timer.fire()
        
    }

    func timeCalculator(dateFormat: String, endTime: String, startTime: Date = Date()) -> DateComponents {
          formatter.dateFormat = dateFormat
          let _startTime = startTime
          
          let _endTime = formatter.date(from: endTime)
          
          
          let timeDifference = userCleander.dateComponents(requestedComponent, from: _startTime, to: _endTime!)
          return timeDifference
          
      }
    
    @objc func timePrinter() -> Void {
    let time = timeCalculator(dateFormat: "MM/dd/yyyy hh:mm:ss a", endTime: "\(timedate[0])")
        
        // It can't access UITableView Cells, too!
        CountdownTimeLBL.text = "\(time.month!) MOS \(time.day!) DAYS \(time.hour!) HRS \(time.minute!) MINS \(time.second!) SECS"
              
         }
    
    

}


extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return timedate.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let timeCells = TimeTableView.dequeueReusableCell(withIdentifier: "TimerCells") as? TimeTableViewCell
        timeCells!.TitleLBL.text = typeevent[indexPath.row]
        
        // MARK: How can I solved it?
        
      /*
         
    
     timeCells?.CountdownTimeLBL.text = ???
         
     */
        
        return timeCells!
        
    }
    
    
    
}
